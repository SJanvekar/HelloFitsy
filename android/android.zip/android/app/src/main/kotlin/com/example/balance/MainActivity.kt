package com.example.balance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
